PCM Voice Notes - Download All
97 short voice notes (audio/) + companion text per chapter (companion-text/).
Full 30+ min course tracks live in the course/ folder on the site, per chapter.

11 Che Ch  1 - Some Basic Concepts of Chemistry
11 Che Ch  2 - Introduction to Analytical Chemistry
11 Che Ch  3 - Basic Analytical Techniques
11 Che Ch  4 - Structure of Atom
11 Che Ch  5 - Chemical Bonding
11 Che Ch  6 - Redox Reactions
11 Che Ch  7 - Modern Periodic Table
11 Che Ch  8 - Elements of Group 1 and 2 (s-Block)
11 Che Ch  9 - Elements of Groups 13, 14, 15 (p-Block part 1)
11 Che Ch 10 - States of Matter (Gaseous & Liquid)
11 Che Ch 11 - Adsorption and Colloids
11 Che Ch 12 - Chemical Equilibrium
11 Che Ch 13 - Nuclear Chemistry and Radioactivity
11 Che Ch 14 - Basic Principles of Organic Chemistry (GOC)
11 Che Ch 15 - Hydrocarbons
11 Che Ch 16 - Chemistry in Everyday Life
12 Che Ch  1 - Solid State
12 Che Ch  2 - Solutions
12 Che Ch  3 - Ionic Equilibria
12 Che Ch  4 - Chemical Thermodynamics
12 Che Ch  5 - Electrochemistry
12 Che Ch  6 - Chemical Kinetics
12 Che Ch  7 - Elements of Groups 16, 17, 18
12 Che Ch  8 - Transition and Inner Transition Elements
12 Che Ch  9 - Coordination Compounds
12 Che Ch 10 - Halogen Derivatives
12 Che Ch 11 - Alcohols, Phenols, Ethers
12 Che Ch 12 - Aldehydes, Ketones, Carboxylic Acids
12 Che Ch 13 - Amines
12 Che Ch 14 - Biomolecules
12 Che Ch 15 - Polymers
12 Che Ch 16 - Green Chemistry & Nanochemistry
11 Mat Ch  1 - Angle and its Measurement
11 Mat Ch  2 - Trigonometry 1
11 Mat Ch  3 - Trigonometry 2
11 Mat Ch  4 - Determinants and Matrices
11 Mat Ch  5 - Straight Line
11 Mat Ch  6 - Circle
11 Mat Ch  7 - Conic Sections
11 Mat Ch  8 - Measures of Dispersion (Statistics)
11 Mat Ch  9 - Probability
11 Mat Ch 10 - Complex Numbers
11 Mat Ch 11 - Sequences and Series
11 Mat Ch 12 - Permutations and Combinations
11 Mat Ch 13 - Methods of Induction & Binomial Theorem
11 Mat Ch 14 - Sets and Relations
11 Mat Ch 15 - Functions
11 Mat Ch 16 - Limits
11 Mat Ch 17 - Continuity
11 Mat Ch 18 - Differentiation (11th)
12 Mat Ch  1 - Mathematical Logic
12 Mat Ch  2 - Matrices
12 Mat Ch  3 - Trigonometric Functions
12 Mat Ch  4 - Pair of Straight Lines
12 Mat Ch  5 - Vectors
12 Mat Ch  6 - Line and Plane (3D Geometry)
12 Mat Ch  7 - Linear Programming
12 Mat Ch  8 - Differentiation
12 Mat Ch  9 - Applications of Derivatives
12 Mat Ch 10 - Indefinite Integration
12 Mat Ch 11 - Definite Integration
12 Mat Ch 12 - Applications of Definite Integration (Area)
12 Mat Ch 13 - Differential Equations
12 Mat Ch 14 - Probability Distribution
12 Mat Ch 15 - Bernoulli Trials & Binomial Distribution
11 Phy Ch  1 - Units and Measurements
11 Phy Ch  2 - Mathematical Methods
11 Phy Ch  3 - Motion in a Plane (+ Kinematics)
11 Phy Ch  4 - Laws of Motion
11 Phy Ch  5 - Gravitation
11 Phy Ch  6 - Mechanical Properties of Solids
11 Phy Ch  7 - Thermal Properties of Matter
11 Phy Ch  8 - Sound
11 Phy Ch  9 - Optics (Ray Optics)
11 Phy Ch 10 - Electrostatics (11th)
11 Phy Ch 11 - Electric Current through Conductors
11 Phy Ch 12 - Magnetism (11th)
11 Phy Ch 13 - EM Waves and Communication
11 Phy Ch 14 - Semiconductors (11th)
11 Phy Ch 15 - JEE Extras WEP COM
11 Phy Ch 16 - JEE Experimental Skills
12 Phy Ch  1 - Rotational Dynamics
12 Phy Ch  2 - Mechanical Properties of Fluids
12 Phy Ch  3 - Kinetic Theory of Gases and Radiation
12 Phy Ch  4 - Thermodynamics
12 Phy Ch  5 - Oscillations
12 Phy Ch  6 - Superposition of Waves
12 Phy Ch  7 - Wave Optics
12 Phy Ch  8 - Electrostatics
12 Phy Ch  9 - Current Electricity
12 Phy Ch 10 - Magnetic Fields due to Electric Current
12 Phy Ch 11 - Magnetic Materials
12 Phy Ch 12 - Electromagnetic Induction
12 Phy Ch 13 - AC Circuits
12 Phy Ch 14 - Dual Nature of Radiation and Matter
12 Phy Ch 15 - Structure of Atoms and Nuclei
12 Phy Ch 16 - Semiconductor Devices
